package stackqueue;

import java.util.Scanner;
class Node 
{
	int data;
	Node next;
	  public Node(int a)
	 {
		 data=a;
		 next=null;
	 }
	public  Node()
	  {
		  
	  }  
}
 class ListProg1
{
	Node head;
	public ListProg1()
	{
		head=null;
	}
	public void pushEnd(int nu)
	{
		Node n = new Node(nu);
		if(head==null)
		{
			head=n;
		}
		else
		{
			Node temp = head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp.next=n;
		}
	}
	public void pushFront(int nu)
	{
		Node n = new Node(nu);
		if(head==null)
		{
			head=n;
		}
		else
		{
			n.next=head;
			head=n;
		}
	}
	public int popatfront()
	{
		Node temp=head;
		Node sec=null;
		if(head==null)
		{
			System.out.println("Steque is empty.");
			
		}
		 if(head.next==null)
			{
				int ele=head.data;
				head=null;
				return ele;
			}
		else
		 {	
			 int ele=head.data;
			 head=head.next;
			return ele;
		 }
		
	}
	public void disply()
	{	
		if(head==null)
		{
			System.out.println("Steque is empty.");
			
		}
		Node temp=head;
		while(temp!=null)
		{	System.out.print(temp.data+",");
		
			temp=temp.next;
		}
	}
	public int popEnd()
	{
			if(head==null)
				
			{
				System.out.println("empty");
				return -1;
			}
			else if(head.next==null)
			{Node temp1=head;
			head=null;
				return temp1.data;
			}
			else
			{
				Node temp1=head;
			
			while(temp1.next.next!=null)
			{
				temp1=temp1.next;
			}
			//temp1=temp1.next;
			temp1.next=null;
			return temp1 .data;
			}
		}
	}


public class Staque {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc = new Scanner(System.in);
     int num = sc.nextInt();
     for(int i=0;i<num+1;i++)
     {
    	 ListProg1 lp = new ListProg1();
    	 for(int j=0;j<50;j++)
    	 {
             String str ;
             str=sc.nextLine();
             if(str.length()==0)
            	 break;
             String[] s = new String[1];
             s = str.split(" ");
             switch(s[0])
             {
             case "pop" :
             {
            	 lp.popatfront();
            	 lp.disply();
            	 System.out.println(" ");
            	 break;
             }
             case "push" :
             {
            	 lp.pushFront((Integer.parseInt(s[1])));
            	 lp.disply();
            	 System.out.println(" ");
            	 break;
             }
             case "enqueue" :
             {
            	 lp.pushEnd((Integer.parseInt(s[1])));
            	 lp.disply();
            	 System.out.println(" ");
            	 break;
             }
             default : 
             {
            	 System.out.println("no");
             }
             }
    	 }
     }
	}
}
