package Array;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch1 {
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
	int count=0;
	int i=0,j,k,l;
	System.out.println("enter size");
	int n=sc.nextInt();
int  q[]=new int[n];
		while(sc.hasNext() ) {
			 q[i] =  sc.nextInt();
			 i++;
		}
		Arrays.sort(q);
		for(j=0,k=q.length;j!=k;j++,k--)
		{
	
				for(l=0;l<q.length;l++)
				{
					if(q[j]+q[k]+q[l]==0)
					{
						count++;
					}
				}
			
		}
		System.out.println(count);
	}
	

}
