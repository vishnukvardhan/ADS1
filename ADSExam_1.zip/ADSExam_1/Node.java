package ADSExam1;
 class Node 
{
	int data;
	Node next;
	  public Node(int a)
	 {
		 data=a;
		 next=null;
	 }
	public  Node()
	  {
		  
	  }
	  
	  

}
