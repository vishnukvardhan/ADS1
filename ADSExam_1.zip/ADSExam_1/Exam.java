package ADSExam1;

import java.util.Scanner;

class List
{
	Node head;
	
	public List() 
	{
		
		head=null;
	}
	public void push(int a)
	{
		Node n=new Node(a);
		if(head==null)
		{
			head=n;
		}
		else
		{
			
		
		Node temp =head;
		
		while(temp.next!=null)
		{
			temp=temp.next;
		}
		
		temp.next=n;
		}
	}
	
	
	public int popatlast()
	{
		Node temp=head;
		Node sec=null;
		if(head==null)
		{
			System.out.println("no node in list");
		}
		 if(head.next==null)
		{
			int ele=head.data;
			head=null;
			return ele;
		}
		else
		{
		while(temp.next!=null)
		{
			sec = temp;
			temp = temp.next;
			
		}
		sec.next = null;
		return temp.data;
		

		}
	}
	
	public int popatfront()
	{
		Node temp=head;
		Node sec=null;
		if(head==null)
		{
			System.out.println("no node in list");
			
		}
		 if(head.next==null)
			{
				int ele=head.data;
				head=null;
				return ele;
			}
		else
		 {	
			 int ele=head.data;
			 head=head.next;
			return ele;
		 }
		
	}
	
	public void disply()
	{	
		Node temp=head;
		while(temp!=null)
		{	System.out.print(temp.data);
		
			temp=temp.next;
		}
	}
	/*void addAll()
	{
		int s=0;
		Node temp=head;
		//List l = new List();
	    //List l1 = new List();
		while(temp!=null)
		{
		int number = l.popatlast();
		int number1 = l1.popatlast();
		int sum = number + number1 + s;
		if(sum>9)
		{
			 s = sum/10;
		}
		else s=0;
		System.out.println(sum);
		temp=temp.next;
		}
	}*/
	}
public class Exam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=0,count=0,cou=0,cou1=0,count22=0;
		String str = "1";
        Scanner sc = new Scanner(System.in);
        String[] ss  = new String[3];
		List l = new List();
		List l1 = new List();
		for(int i=0;i<3;i++)
		{
			ss[i] = sc.nextLine();
		}
		if(ss[0].equals("numberToDigits"))
		{
			for(int j=0;j<ss[1].length();j++)
		    {
		    	char c = ss[1].charAt(j);
		    	int cc = c;
		    	l.push((cc-48));
		    }
			for(int j=0;j<ss[2].length();j++)
		    {
		    	char c = ss[2].charAt(j);
		    	int cc = c;
		    	l1.push((cc-48));
		    }
			l.disply();
			System.out.println("");
			l1.disply();
			
		}
		else if(ss[0].equals("addLargeNumbers"))
		{
			for(int j=0;j<ss[1].length();j++)
		    {
		    	char c = ss[1].charAt(j);
		    	int cc = c;
		    	l.push((cc-48));
		    	cou1++;
		    }
			for(int j=0;j<ss[2].length();j++)
		    {
		    	char c = ss[2].charAt(j);
		    	int cc = c;
		    	l1.push((cc-48));
		    	cou++;
		    }
		    for( int y=0;y<cou1;y++)
		    {
		    //	if(y<=cou1)
		     // 	{
				int number = l.popatlast();
				int number1 = l1.popatlast();
				int sum = number + number1 + s;
				if(sum>9)
				{
					 s = sum/10;
					 count++;
				}
				else {s=0;count++;}
				if(count==1)
				{
					int rev = sum/10;
					sum = sum%10;
				str = Integer.toString(sum);
				str = str + Integer.toString(rev);
			  //  System.out.println("sum"+sum);
				}
				else
				str = str + Integer.toString(s);
			//	System.out.println(s);
			//	}
		 /*   	else
		    	{
		    		int number5 = l1.popatlast();
		    		int ok = number5 + s;
		    		if(ok>9)
					{
						 s = ok/10;
						 count22++;
					}
					else {s=0;count22++;}
					if(count==1)
					{
					str = Integer.toString(ok);	
				    //System.out.print(sum);
					}
					else
					str = str + Integer.toString(s);
					}*/
		    	}
		    for( int x=str.length()-1;x>=0;x--)
		    {
		    	System.out.print(str.charAt(x));
		    }
		    }
		    
		   
		}
	}

