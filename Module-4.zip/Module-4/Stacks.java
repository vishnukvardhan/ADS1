package Module4;

import java.util.Scanner;

class StacksArray
{
	int[] s; 
	int top=-1,i=0,len;
	 StacksArray(int n)
			{
				s = new int[n];
				this.len=n;
			}
	 boolean isEmpty()
	 {
		if(top==-1)
			return true;
		else 
			return false;
	 }
	 boolean isFull()
	 {
		if(top==len)
			return true;
		else 
			return false;
	 }
	 void push(int num)
	 {   
		 if(!isFull())
		 {
		 top++;
		 s[top]=num;
		 }
	 }
	 int pop()
	 {
		 if(!isEmpty())
		 {
		 int number=s[top];
		 top--;
		 return number;
		 }
		 return 1;
	 }
	 void display() {
	 
		// for(int j=0;j<=top;j++)
		System.out.println(pop());
	 }
}
public class Stacks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ss;int cas = 0;
		//String[]ss1 = new String[20]; 
		Scanner sc = new Scanner(System.in);
		ss = sc.nextLine();
		StacksArray sa = new StacksArray(ss.length());
		String ss1[] = ss.split(" ");
	
	//	System.out.println(ss1[0]+" "+ss1[1]+" "+ss1[2]);
		for(int i=0;i<ss1.length;i++)
		{
			if(ss1[i].equals("+"))
			{
				cas = 1;
			}
			else if(ss1[i].equals("*"))
			{
				cas = 2;
			}
			switch(cas)
			{
			case 1:
			{		
				int a = sa.pop();
				int b = sa.pop();
				int sum  = a+b;
				sa.push(sum);
				break;
			}	
				case 2:
				{
					int a = sa.pop();
					int b = sa.pop();
					int sum  = a*b;
					sa.push(sum);
					break;
			    }
				default : 
				{
					int send = Integer.parseInt(ss1[i]);
					sa.push(send);
				}
			}
		}
		sa.display();
	}

}
