
import java.util.Scanner;

class StudentData
{
	String roll;
	String name;
	double marks;
	public StudentData(String roll, String name, double marks) {
		super();
		this.roll = roll;
		this.name = name;
		this.marks = marks;
	}
}
 class Hash{
	int hashing(String roll)
	{
		int ind=0;
		for(int i=0;i<roll.length();i++)
		{
			ind+=i*roll.charAt(i);
		}
		return ind%2001;
	}
 }
public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		StudentData sd[] = new StudentData[2001];
		Hash h = new Hash();
       for(int i=0;i<n;i++)
       {
    	   String str = sc.next();
    	   String s[] = str.split(",");
    	   sd[h.hashing(s[0])]= new StudentData(s[0],s[1],Double.parseDouble(s[2]));
    	   //System.out.println(h.hashing(s[0]));
       }
       int n2=sc.nextInt();
       String r=sc.next();
       int count=0;
       for(int i = 0;i<n2;i++)
       {
       	String s1=sc.nextLine();
       	 count=0;
       	String s2[]=s1.split(" ");
       	for(int j = 0;j<s1.length();j++)
       	{
       		if(s2[1].equals(s2[j]))
       		{
       			count++;
       			break;
       		}
       	}
       	if(count==1)
       	{
       	
       	switch (s2[2])
       	{
       	case "1":{
       		System.out.println(sd[h.hashing(s2[1])].name);
       		break;
             	}
       	
       	case "2":{
       		System.out.println(sd[h.hashing(s2[1])].marks);
       		break;
            	}
       	}
       }
       	else
       	{
       		System.out.println("Student doesn't exists...");
       	}
       }
}
}
