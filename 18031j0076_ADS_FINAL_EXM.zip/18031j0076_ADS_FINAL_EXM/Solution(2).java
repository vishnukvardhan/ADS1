import java.util.Scanner;
class StudentData
{
	String rollno;
	String name;
	double total;
	public StudentData(String rollno, String name, double total) 
	{
		this.name = name;
		this.rollno = rollno;
		this.total = total;
	}
}
class Node
{
	StudentData key;
Node left,right;
int size;
public Node(StudentData key,int size) {
	
	this.key = key;
	this.size=size;
}
}
class Bstimp {
	
		Node root;
		void put(StudentData k)
		{	
			root=put(root,k);
		}
		Node put(Node x,StudentData k)
		{
			if(x==null)
			{
				return new Node(k,1);
			}
			if(k<0) {
				x.left=put(x.left,k);
			}
			else if(k>0)
			{
				x.right=put(x.right,k);
			}
			else
				x.key=k;
				
			x.size=1+size(x.left)+size(x.right);
			return x;
		}
		StudentData get(String k,Node x)
		{
			
			while(x!=null)
			{
				
				int cmp=k.compareTo(x.key.name);
				if(cmp<0)
					x=x.left;
				else if(cmp>0)
					x=x.right;
				else
					return x.key;
			}
			return null;
		}
		public int size() {
		    return size(root);
		}
		private int size(Node x) {
		    if (x == null)
		    	return 0;
		    else return x.size;
		}
		public void between(double d1,double d2)
		{
		between(root,d1,d2);
		}
		public void between(Node n,double d1,double d2)
		{
			if(n!=null) {	
			between(n.left,d1,d2);
			
			between(n.right,d1,d2);
			if(n.key.total>=d1 && n.key.total<=d2)
			{
				System.out.println(n.key.name);
			}
			}
		}
		public void high(double d1)
		{
		high(root,d1);
		}
		public void high(Node n,double d1)
		{
			if(n!=null)
				
			high(n.left,d1);
			high(n.right,d1);
			if(n.key.total>=d1 )
			{
				System.out.println(n.key.name);
			}
			}	
public void low(double d1)
{
low(root,d1);
}
public void low(Node n,double d1)
{
	if(n!=null)
{
	low(n.left,d1);
	
	low(n.right,d1);
	if(n.key.total<=d1 )
	{
		System.out.println(n.key.name);
	}
	}
}
}
public class Solution2 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n1=s.nextInt();
		Bstimp b=new Bstimp();
	String se=s.nextLine();
	String string[]=new String[n1];
	for(int i = 0;i<n1;i++)
	{
		String s1=s.nextLine();
		String s2[]=s1.split(",");
		StudentData sd=new StudentData(s2[0],s2[1],Double.parseDouble(s2[2]));
	b.put(sd);
	}
	int n2=s.nextInt();
	for(int i = 0;i<n2+1;i++)
	{
		String s1=s.nextLine();
		String s2[]=s1.split(" ");
		switch(s2[0])
		{
		case "BE":double a=Double.parseDouble(s2[1]),a1=Double.parseDouble(s2[2]);
		b.between(a,a1);
			
			break;
		case "GE":
			double c1=Double.parseDouble(s2[1]);
			b.high(c1);
			break;
		case "LE":
			double c2=Double.parseDouble(s2[1]);
			b.low(c2);
			break;
		}
	}
	}
}
